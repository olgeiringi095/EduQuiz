# EduQuiz
Team 10. Birkir, Einar Olgeir og Sveinn.

Leiðbeinandi: Sigurður.

### Prerequisites
Java 8.

Dependencies í pom.xml.

H2 gagnagrunnur er notaður og upphafleg gögn eru sjálfkrafa sett inn með insert skipunum frá data.sql.

### Uppsetning og Keyrsla

Annaðhvort clone'a Github repo eða nota .zip skránna.

Keyra verkefnið í IDE (einungis prófað í IntelliJ).

Fara á slóðina http://localhost:8080/ vafra (einungis prófað í Google Chrome).

Inniheldur tvö spilanleg quiz: Háskólabyggingar og Tilvitnanir úr Kvikmyndum.


##
Takk fyrir misserið.
