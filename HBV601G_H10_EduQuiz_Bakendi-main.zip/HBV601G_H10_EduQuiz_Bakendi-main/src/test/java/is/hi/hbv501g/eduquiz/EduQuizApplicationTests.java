package is.hi.hbv501g.eduquiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduQuizApplicationTests {

	@Test
	void contextLoads() {
	}

}
